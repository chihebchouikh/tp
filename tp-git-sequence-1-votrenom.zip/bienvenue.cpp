// TODO Indiquer ce que fait le programme
int main()
{
// TODO Afficher un message de bienvenue
return 1;
}

